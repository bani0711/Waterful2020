package com.example.waterful;

/* 친구 목록 구성 클래스 */
public class FriendsInfo {
    public int drawbleID;
    public String nickname;

    public FriendsInfo(int drawbleID, String nickname) {
        this.drawbleID = drawbleID;
        this.nickname = nickname;
    }
}
