package com.example.waterful;

/* 메인 페이지 */

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;

import me.itangqi.waveloadingview.WaveLoadingView;


public class MainFragment extends Fragment {
private View view;
ImageButton ibtnFriends;
WaveLoadingView waveLoadingView;
EditText edtIntake, edtDialog;
TextView tvUserNickName, tvDialog;
FloatingActionButton fabAdd;

    SharedPreferences sp, sp2;

    String url = "http://172.18.85.233:8080/Waterful/drinking";
    ContentValues values = new ContentValues();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             final Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_main, container, false);
        Log.d("dhkim", "onCreateView");


        MainActivity activity = (MainActivity)getActivity();
        sp = activity.getSharedPreferences("WaterfulApp",Context.MODE_PRIVATE);
        sp2 = activity.getSharedPreferences("WaterData",Context.MODE_PRIVATE);

        //닉네임 preferences에서 불러오기
        tvUserNickName = view.findViewById(R.id.tvUserNickName);
        String nickname = sp.getString("nickname", "");
        tvUserNickName.setText(nickname);

        //음수량 프로그레스바 설정
        waveLoadingView = view.findViewById(R.id.waveLoadingView);
        waveLoadingView.setShapeType(WaveLoadingView.ShapeType.CIRCLE);
        waveLoadingView.setAnimDuration(3000);
        edtIntake = view.findViewById(R.id.edtIntake);

        int water = sp2.getInt("per_day_water", -1);
        if(water!=-1){
            edtIntake.setText(String.valueOf(water));
            //섭취량 edtIntake에서 값 얻어와서 백분율 계산하기 (일부값/전체값*100) -> 결과값에 따라 프로그레스바 높이가 달라짐
            String part = edtIntake.getText().toString();
            String total = waveLoadingView.getTopTitle().replaceAll("[^0-9]", ""); //숫자만 추출 (2000ml 이면 2000만 추출)
            int intake = (int)(Double.parseDouble(part) / Double.parseDouble(total) * 100.0);
            waveLoadingView.setProgressValue(intake);

            //100% 이상이면 걍 100으로 출력되게
            if(waveLoadingView.getProgressValue() >= 100) {
                waveLoadingView.setCenterTitle("100%");
            } else {
                waveLoadingView.setCenterTitle(intake + "%");
            }

            //음수량 프로그레스바 양 얻어오기
            int pValue = waveLoadingView.getProgressValue();

            //음수량 프로그레스바가 일정 높이 이상이면 안의 텍스트 색상을 변경함
            if(pValue >= 60) {
                waveLoadingView.setCenterTitleColor(Color.WHITE);
            }
            if(pValue >= 100) {
                waveLoadingView.setTopTitleColor(Color.WHITE);
            }
        }

        //권장량
        int recommend = sp.getInt("recommend",0);
        waveLoadingView.setTopTitle(recommend + " ml");

        //입력 값 변화 이벤트
        edtIntake.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                //입력되는 텍스트에 변화가 있을 때
            }

            @Override
            public void afterTextChanged(Editable s) {
                //섭취량 edtIntake에서 값 얻어와서 백분율 계산하기 (일부값/전체값*100) -> 결과값에 따라 프로그레스바 높이가 달라짐
                String part = edtIntake.getText().toString();
                String total = waveLoadingView.getTopTitle().replaceAll("[^0-9]", ""); //숫자만 추출 (2000ml 이면 2000만 추출)
                int intake = (int)(Double.parseDouble(part) / Double.parseDouble(total) * 100.0);
                waveLoadingView.setProgressValue(intake);

                //100% 이상이면 걍 100으로 출력되게
                if(waveLoadingView.getProgressValue() >= 100) {
                    waveLoadingView.setCenterTitle("100%");
                } else {
                    waveLoadingView.setCenterTitle(intake + "%");
                }

                //음수량 프로그레스바 양 얻어오기
                int pValue = waveLoadingView.getProgressValue();

                //음수량 프로그레스바가 일정 높이 이상이면 안의 텍스트 색상을 변경함
                if(pValue >= 60) {
                    waveLoadingView.setCenterTitleColor(Color.WHITE);
                }
                if(pValue >= 100) {
                    waveLoadingView.setTopTitleColor(Color.WHITE);
                }
            }
        });

        //음수량 프로그레스바 클릭 이벤트
        waveLoadingView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d("dhkim", "OnClickListener");
                url = "http://172.18.85.233:8080/Waterful/drinking/record";
                values.put("user_ucode", sp.getString("ucode",""));

                NetworkTask networkTask2 = new NetworkTask(url, values);
                networkTask2.execute();

                //dhkim -->

//                Intent intent = new Intent(getActivity(), RecordActivity.class);
//                startActivity(intent);
            }
        });

        //친구목록 아이콘 클릭 이벤트
        ibtnFriends = view.findViewById(R.id.ibtnFriends);
        ibtnFriends.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), FriendsActivity.class);
                startActivity(intent);
            }
        });




       return view;
    }//onCreate



    public String getFragmentText() {
        String s = edtIntake.getText().toString();
        return s;
    }

    public void setFragmentText() {
        SharedPreferences sp2 = this.getActivity().getSharedPreferences("WaterData",Context.MODE_PRIVATE);
        int water = sp2.getInt("per_day_water", -1);
        Log.i("water값", String.valueOf(water));
        edtIntake.setText(String.valueOf(water));

    }

        public class NetworkTask extends AsyncTask<JSONArray, Void, Void> {

            String url;
            ContentValues values;

            NetworkTask(String url, ContentValues values) {
                Log.i("networktask", "network");
                this.url = url;
                this.values = values;
                Log.d("dhkim", values.getAsString("user_ucode"));
            }

            @Override
            protected Void doInBackground(JSONArray... jsonArrays) {
                Log.i("doInbackground", "값넣기");

                Log.d("dhkim","doInBackground");

                RequestHttpURLConnection requestHttpURLConnection = new RequestHttpURLConnection();
                JSONArray result = requestHttpURLConnection.request(url, values);

                JSONObject obj;
                SharedPreferences.Editor editor = sp2.edit();

                editor.putInt("array_size", result.length());
                Log.d("dhkim","result.length(): "+ result.length());

                for (int i = 0; i < result.length(); i++) {
                    try {
                        obj = result.getJSONObject(i);

                        editor.putString("cur_time" + i, obj.getString("cur_time"));
                        editor.putInt("drinking_water" + i, obj.getInt("drinking_water"));
                        editor.apply();
                        Log.d("dhkim","cur_time"+ obj.getString("cur_time"));
                        Log.d("dhkim","drinking_water"+ obj.getString("drinking_water"));

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                editor.commit();

                Log.d("dhkim","doInBackground done");
                return null;
            }
        }

}