package com.example.waterful;

/* 랭킹 목록 구성 클래스 */
public class RankingInfo {
    public String ranking;
    public int drawbleID;
    public String nickname;
    public String achivePoint;

    public RankingInfo(String ranking, int drawbleID, String nickname, String achivePoint) {
        this.ranking = ranking;
        this.drawbleID = drawbleID;
        this.nickname = nickname;
        this.achivePoint = achivePoint;
    }
}
