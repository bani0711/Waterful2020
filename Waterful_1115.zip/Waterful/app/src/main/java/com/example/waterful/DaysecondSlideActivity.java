package com.example.waterful;
// day 두번째 차트
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;

import java.util.ArrayList;

public class DaysecondSlideActivity extends Fragment {
    BarChart bar2;
    ArrayList<BarEntry> bar2Entry;
    ArrayList<String> bar2EntryLabel;
    BarDataSet bar2DataSet;
    BarData bar2Data;

    public DaysecondSlideActivity() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,  Bundle savedInstanceState) {
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.daysecond_slide, container, false);

        //bar차트 기본 설정
        bar2 = rootView.findViewById(R.id.barChart2);
        bar2Entry = new ArrayList<>();
        bar2EntryLabel = new ArrayList<>();
        AddValues();
        barEntryLabels();

        bar2DataSet = new BarDataSet(bar2Entry, "섭취량");
        bar2Data = new BarData(bar2EntryLabel, bar2DataSet);
        bar2DataSet.setColor(ContextCompat.getColor(getContext(),R.color.colorPrimary));

        XAxis xAxis = bar2.getXAxis(); // x 축 설정
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM); //x 축 표시에 대한 위치 설정
        xAxis.setTextColor(ContextCompat.getColor(getContext(),R.color.colorPrimaryDark)); // X축 텍스트컬러설정
        xAxis.setGridColor(ContextCompat.getColor(getContext(), R.color.colorWhite)); // X축 줄의 컬러 설정

        YAxis yAxisLeft = bar2.getAxisLeft(); //Y축의 왼쪽면 설정
        yAxisLeft.setTextColor(ContextCompat.getColor(getContext(), R.color.colorPrimaryDark)); //Y축 텍스트 컬러 설정
        yAxisLeft.setGridColor(ContextCompat.getColor(getContext(), R.color.colorWhite)); // X축 줄의 컬러 설정

        YAxis yAxisRight = bar2.getAxisRight(); //Y축의 오른쪽면 설정
        yAxisRight.setDrawLabels(false);
        yAxisRight.setDrawAxisLine(false);
        yAxisRight.setDrawGridLines(false);

        bar2.setData(bar2Data);
        bar2.animateY(3000); //그래프 그릴 시 y축으로 애니메이션

        return rootView;
    }
    //임의로 막대 그래프 값을 넣음
    //BarEntry 값에 따라 y축 단위와 최대값이 변함
    public void AddValues(){
        bar2Entry.add(new BarEntry(1002f, 0));
        bar2Entry.add(new BarEntry(1800f, 1));
        bar2Entry.add(new BarEntry(500f, 2));
        bar2Entry.add(new BarEntry(0f, 3));
        bar2Entry.add(new BarEntry(800f, 4));
        bar2Entry.add(new BarEntry(100f, 5));
        bar2Entry.add(new BarEntry(1100f, 6));
        bar2Entry.add(new BarEntry(1002f, 7));
        bar2Entry.add(new BarEntry(1800f, 8));
        bar2Entry.add(new BarEntry(500f, 9));
        bar2Entry.add(new BarEntry(0f, 10));
        bar2Entry.add(new BarEntry(800f, 11));
        bar2Entry.add(new BarEntry(100f, 12));
        bar2Entry.add(new BarEntry(1100f, 13));
        bar2Entry.add(new BarEntry(800f, 14));
        bar2Entry.add(new BarEntry(100f, 15));
    }

    //x축
    public void barEntryLabels(){
        bar2EntryLabel.add("16");
        bar2EntryLabel.add("17");
        bar2EntryLabel.add("18");
        bar2EntryLabel.add("19");
        bar2EntryLabel.add("20");
        bar2EntryLabel.add("21");
        bar2EntryLabel.add("22");
        bar2EntryLabel.add("23");
        bar2EntryLabel.add("24");
        bar2EntryLabel.add("25");
        bar2EntryLabel.add("26");
        bar2EntryLabel.add("27");
        bar2EntryLabel.add("28");
        bar2EntryLabel.add("29");
        bar2EntryLabel.add("30");
        bar2EntryLabel.add("31");
    }
}