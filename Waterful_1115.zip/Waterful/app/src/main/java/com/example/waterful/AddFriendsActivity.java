package com.example.waterful;

/* 설정 페이지 - 친구 추가하기 */

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class AddFriendsActivity extends AppCompatActivity {
TextView tvUserCode;
EditText edtUserCode;
Button btnAddFriends;
Toolbar toolbarAddFriends;
ActionBar actionBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addfriends);

        tvUserCode = findViewById(R.id.tvUserCode);
        edtUserCode = findViewById(R.id.edtUserCode);
        btnAddFriends = findViewById(R.id.btnAddFriends);

        //Toolbar 구현 코드
        toolbarAddFriends = findViewById(R.id.toolbarAddFriends);
        setSupportActionBar(toolbarAddFriends);
        actionBar = getSupportActionBar();
        actionBar.setDisplayShowCustomEnabled(true);
        actionBar.setDisplayShowTitleEnabled(false);

        //뒤로가기 아이콘
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeAsUpIndicator(R.drawable.ic_back_24);


        //추가하기 버튼 클릭 이벤트
        btnAddFriends.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String friendsCode = edtUserCode.getText().toString();
                Toast.makeText(AddFriendsActivity.this, "추가되었습니다.", Toast.LENGTH_LONG).show();
            }
        });
    }

    //툴바 뒤로가기 버튼 동작 메서드
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId()) {
            case android.R.id.home: {
                finish();
                return true;
            }
        }
        return super.onOptionsItemSelected(item);
    }

}