package com.example.waterful;

/* 업적내용 구성 클래스 */
public class QuestInfo {
    public String quest;
    public String questPoint;

    public QuestInfo(String quest, String questPoint) {
        this.quest = quest;
        this.questPoint = questPoint;
    }
}
