package com.example.waterful;

/* 업적 페이지 - 내 업적 */

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.ArrayList;


public class QuestFragment extends Fragment {
private View view;
RecyclerView recyclerViewQ;
ImageButton ibtnRanking;
ImageView ivComplete;
TextView tvQuestProgress,tvUserName;
ProgressBar pbQuestProgress;

    SharedPreferences sp;
    public static final String MyPREFERENCES = "WaterfulApp";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_quest, container, false);

        sp = getActivity().getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);

        tvUserName = view.findViewById(R.id.tvUserName);
        String nickname = sp.getString("nickname", "");
        tvUserName.setText(nickname);

        //랭킹 아이콘 클릭 이벤트
        ibtnRanking = view.findViewById(R.id.ibtnRanking);
        ibtnRanking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), RankingActivity.class);
                startActivity(intent);
            }
        });

        //총 업적 진행도 부분 추가해야 함

        //RecyclerView 구현 코드
        recyclerViewQ = view.findViewById(R.id.recyclerViewQ);
        recyclerViewQ.setHasFixedSize(true);
        recyclerViewQ.setLayoutManager(new LinearLayoutManager(getActivity()));

        ArrayList<QuestInfo> questInfoArrayList = new ArrayList<>();
        questInfoArrayList.add(new QuestInfo("성취내용1", "1point"));
        questInfoArrayList.add(new QuestInfo("성취내용2", "1point"));
        questInfoArrayList.add(new QuestInfo("성취내용3", "1point"));
        questInfoArrayList.add(new QuestInfo("성취내용4", "1point"));
        questInfoArrayList.add(new QuestInfo("성취내용5", "1point"));

        QuestAdapter questAdapter = new QuestAdapter(questInfoArrayList);

        recyclerViewQ.setAdapter(questAdapter);

//        //성취 완료 된 경우 체크처리
//        if(조건문 못찾음) {
//            ivComplete = view.findViewById(R.id.ivComplete);
//            ivComplete.setVisibility(View.VISIBLE);
//        }

        //성취 진행도 프로그레스바 조절
        tvQuestProgress = view.findViewById(R.id.tvQuestProgress);
        pbQuestProgress = view.findViewById(R.id.pbQuestProgress);
        int value = Integer.parseInt(tvQuestProgress.getText().toString().replaceAll("[^0-9]", "")); // 00% 중 숫자(00)만 추출

        pbQuestProgress.setProgress(value);


        return view;
    }
}