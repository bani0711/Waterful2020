package com.example.waterful;

/* 업적 페이지 - 순위 - 친구랭킹 */

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;


public class FriendsRankingFragment extends Fragment {
RecyclerView recyclerViewFR;
private View view;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_friends_ranking, container, false);

        recyclerViewFR = view.findViewById(R.id.recyclerViewFR);

        recyclerViewFR.setHasFixedSize(true);
        recyclerViewFR.setLayoutManager(new LinearLayoutManager(getActivity()));

        //친구랭킹 리사이클러뷰에 요소 추가
        ArrayList<RankingInfo> rankingInfoArrayList = new ArrayList<>();
        rankingInfoArrayList.add(new RankingInfo("1", R.drawable.userprofile, "유저1", "999"));
        rankingInfoArrayList.add(new RankingInfo("2", R.drawable.userprofile, "유저2", "899"));
        rankingInfoArrayList.add(new RankingInfo("3", R.drawable.userprofile, "유저3", "799"));
        rankingInfoArrayList.add(new RankingInfo("4", R.drawable.userprofile, "유저4", "699"));
        rankingInfoArrayList.add(new RankingInfo("5", R.drawable.userprofile, "유저5", "599"));
        rankingInfoArrayList.add(new RankingInfo("6", R.drawable.userprofile, "유저6", "499"));
        rankingInfoArrayList.add(new RankingInfo("7", R.drawable.userprofile, "유저7", "399"));

        RankingAdapter rankingAdapter = new RankingAdapter(rankingInfoArrayList);

        //어댑터 적용
        recyclerViewFR.setAdapter(rankingAdapter);

        return view;
    }
}