package com.example.waterful;

/* 메인 페이지 - 친구목록 */

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.MenuItem;

import java.util.ArrayList;

public class FriendsActivity extends AppCompatActivity {
RecyclerView recyclerView;
RecyclerView.LayoutManager layoutManager;
ArrayList<FriendsInfo> friendsInfoArrayList = new ArrayList<>();
MyAdapter myAdapter = new MyAdapter(friendsInfoArrayList);
Toolbar toolbarFriends;
ActionBar actionBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friends);

        //Toolbar 구현 코드
        toolbarFriends = findViewById(R.id.toolbarFriends);
        setSupportActionBar(toolbarFriends);
        actionBar = getSupportActionBar();
        actionBar.setDisplayShowCustomEnabled(true);
        actionBar.setDisplayShowTitleEnabled(false);

        //뒤로가기 아이콘
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeAsUpIndicator(R.drawable.ic_back_24);

        //RecyclerView 구현 코드
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        //구현된 RecyclerView에 개체 추가하기
        friendsInfoArrayList.add(new FriendsInfo(R.drawable.userprofile, "친구1"));
        friendsInfoArrayList.add(new FriendsInfo(R.drawable.userprofile, "친구2"));
        friendsInfoArrayList.add(new FriendsInfo(R.drawable.userprofile, "친구3"));
        friendsInfoArrayList.add(new FriendsInfo(R.drawable.userprofile, "친구4"));
        friendsInfoArrayList.add(new FriendsInfo(R.drawable.userprofile, "친구5"));


        //어댑터 적용
        recyclerView.setAdapter(myAdapter);

        //스와이프 삭제 기능 구현을 위한 ItemTouchHelper 객체 생성
        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(simpleItemTouchCallback);
        itemTouchHelper.attachToRecyclerView(recyclerView);
    }

    //스와이프 삭제 기능 구현을 위한 ItemTouchHelper
    ItemTouchHelper.SimpleCallback simpleItemTouchCallback = new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT) {
        @Override
        public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
            return false;
        }

        //스와이프 했을 때의 동작
        @Override
        public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
            //스와이프 했을 때 remove(삭제) 하기
            final int position = viewHolder.getAdapterPosition();
            friendsInfoArrayList.remove(position);
            myAdapter.notifyItemRemoved(position);
        }
    };

    //툴바 뒤로가기 버튼 동작 메서드
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId()) {
            case android.R.id.home: {
                finish();
                return true;
            }
        }
        return super.onOptionsItemSelected(item);
    }
}
