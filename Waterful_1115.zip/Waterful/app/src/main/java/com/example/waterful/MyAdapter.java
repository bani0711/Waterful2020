package com.example.waterful;

/* 메인 페이지 - 리사이클러뷰를 구현하기 위한 친구목록 어댑터 */

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    //RecyclerView의 행을 표시하는 클래스 정의
    public static class MyViewHolder extends RecyclerView.ViewHolder {
        ImageView ivPicture;
        TextView tvNickname;

        MyViewHolder(View view) {
            super(view);
            ivPicture = view.findViewById(R.id.ivPicture);
            tvNickname = view.findViewById(R.id.tvNickname);
        }
    } //MyViewHolder end

    private ArrayList<FriendsInfo> friendsInfoArrayList;
    MyAdapter(ArrayList<FriendsInfo> friendsInfoArrayList) {
        this.friendsInfoArrayList = friendsInfoArrayList;
    }

    //RecyclerView의 행을 표시하는데 사용되는 레이아웃 xml 가져옴
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_view, parent, false);

        return new MyViewHolder(v);
    }

    //RecyclerView의 행에 보여질 iv와 tv 설정
    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        MyViewHolder myViewHolder = (MyViewHolder)holder;

        myViewHolder.ivPicture.setImageResource(friendsInfoArrayList.get(position).drawbleID);
        myViewHolder.tvNickname.setText(friendsInfoArrayList.get(position).nickname);
    }

    //RecyclerView의 행 갯수 리턴
    @Override
    public int getItemCount() {
        return friendsInfoArrayList.size();
    }
}
