package com.example.waterful;

/* 업적 페이지 - 리사이클러뷰를 구현하기 위한 내 업적 어댑터 */

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class QuestAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    //RecyclerView의 행을 표시하는 클래스 정의
    public static class QuestViewHolder extends RecyclerView.ViewHolder {
        TextView tvQuest;

        QuestViewHolder(View view) {
            super(view);
            tvQuest = view.findViewById(R.id.tvQuest);
        }
    } //QuestViewHolder end

    private ArrayList<QuestInfo> questInfoArrayList;
    QuestAdapter(ArrayList<QuestInfo> questInfoArrayList) {
        this.questInfoArrayList = questInfoArrayList;
    }

    //RecyclerView의 행을 표시하는데 사용되는 레이아웃 xml 가져옴
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_view_quest, parent, false);

        return new QuestAdapter.QuestViewHolder(v);
    }

    //RecyclerView의 행에 보여질 tv 설정
    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        QuestAdapter.QuestViewHolder questViewHolder = (QuestAdapter.QuestViewHolder)holder;

        questViewHolder.tvQuest.setText(questInfoArrayList.get(position).quest);
    }

    //RecyclerView의 행 갯수 리턴
    @Override
    public int getItemCount() {
        return questInfoArrayList.size();
    }
}
