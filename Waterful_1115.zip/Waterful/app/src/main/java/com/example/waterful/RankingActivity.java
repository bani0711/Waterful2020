package com.example.waterful;

/* 업적 페이지 - 순위 */

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.graphics.Color;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;

import java.util.ArrayList;

public class RankingActivity extends AppCompatActivity {
FragmentManager fm;
FragmentTransaction ft;
FriendsRankingFragment friendsRankingFragment;
TotalRankingFragment totalRankingFragment;
Switch sRanking;
TextView tvFriends, tvTotal;
Toolbar toolbarRanking;
ActionBar actionBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ranking);

        //Toolbar 구현 코드
        toolbarRanking = findViewById(R.id.toolbarRanking);
        setSupportActionBar(toolbarRanking);
        actionBar = getSupportActionBar();
        actionBar.setDisplayShowCustomEnabled(true);
        actionBar.setDisplayShowTitleEnabled(false);

        //뒤로가기 아이콘
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeAsUpIndicator(R.drawable.ic_back_24);

        tvFriends = findViewById(R.id.tvFriends);
        tvTotal = findViewById(R.id.tvTotal);

        // 친구순위/전체순위 스위치 동작 이벤트
        sRanking = findViewById(R.id.sRanking);
        sRanking.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked) {
                    //프래그먼트 전환(전체랭킹)
                    setFrag(1);
                    tvFriends.setTextColor(Color.BLACK);
                    tvTotal.setTextColor(Color.WHITE);
                } else {
                    //프래그먼트 전환(친구랭킹)
                    setFrag(0);
                    tvTotal.setTextColor(Color.BLACK);
                    tvFriends.setTextColor(Color.WHITE);
                }
            }
        });

        friendsRankingFragment = new FriendsRankingFragment();
        totalRankingFragment = new TotalRankingFragment();

        //디폴트 프래그먼트 지정
        setFrag(0);
    }

    //프래그먼트 지정 메서드
    public void setFrag(int n) {
        fm = getSupportFragmentManager();
        ft = fm.beginTransaction();
        switch (n) {
            case 0:
                //0이면 친구랭킹
                ft.replace(R.id.RankingFrame, friendsRankingFragment);
                ft.commit();
                break;

            case 1:
                //1이면 전체랭킹
                ft.replace(R.id.RankingFrame, totalRankingFragment);
                ft.commit();
                break;
        }
    }

    //툴바 뒤로가기 버튼 동작 메서드
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId()) {
            case android.R.id.home: {
                finish();
                return true;
            }
        }
        return super.onOptionsItemSelected(item);
    }

}