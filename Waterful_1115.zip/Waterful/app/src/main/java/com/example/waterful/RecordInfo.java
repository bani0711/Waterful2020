package com.example.waterful;

/* 데이터 기록 목록 클래스 */
public class RecordInfo {
    public String recordDate;
    public String intake;

    public RecordInfo(String recordDate, String intake) {
        this.recordDate = recordDate;
        this.intake = intake;
    }

    public String getRecordDate() {
        return recordDate;
    }

    public void setRecordDate(String recordDate) {
        this.recordDate = recordDate;
    }

    public String getIntake() {
        return intake;
    }

    public void setIntake(String intake) {
        this.intake = intake;
    }
}
