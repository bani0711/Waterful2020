package com.example.waterful;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import app.akexorcist.bluetotohspp.library.BluetoothSPP;

import static android.R.color.black;

public class SetPrivacyActivity extends AppCompatActivity {
    TextView tvDisconnection;
    Button btnSetWoman, btnSetMan, btnCheck;
    EditText btnSetNickname, btnSetAge, btnSetWeight;
    ImageView ivSetUserImage;
    private final int GET_GALLERY_IMAGE = 200;
    Toolbar toolbarAddSetPrivacy;
    ActionBar actionBar;

    String url = "http://172.18.85.233:8080/Waterful/user";

    SharedPreferences sp;
    public static final String MyPREFERENCES = "WaterfulApp";

    ContentValues values = new ContentValues();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        sp = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);

        setContentView(R.layout.activity_setprivacy);
        btnCheck = findViewById(R.id.btnCheck);
        btnSetNickname = findViewById(R.id.btnSetNickname);
        btnSetAge = findViewById(R.id.btnSetAge);
        btnSetWeight = findViewById(R.id.btnSetWeight);
        btnSetWoman = findViewById(R.id.btnSetWoman);
        btnSetMan = findViewById(R.id.btnSetMan);
        ivSetUserImage = findViewById(R.id.ivSetUserImage);
        tvDisconnection = findViewById(R.id.tvDisconnection);

        //Toolbar 구현 코드
        toolbarAddSetPrivacy = findViewById(R.id.toolbarSetPrivacy);
        setSupportActionBar(toolbarAddSetPrivacy);
        actionBar = getSupportActionBar();
        actionBar.setDisplayShowCustomEnabled(true);
        actionBar.setDisplayShowTitleEnabled(false);

        //뒤로가기 아이콘
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeAsUpIndicator(R.drawable.ic_back_24);

        //사용자 사집첩에서 이미지 선택
        ivSetUserImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_PICK);
                //setDataAndType(mediaStore, image*) : 파일 연결
                intent.setDataAndType(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*");
                startActivityForResult(intent, GET_GALLERY_IMAGE);
            }
        });


        //남,여 선택버튼
        Button.OnClickListener onClickListener = new Button.OnClickListener() {
            @SuppressLint("ResourceAsColor")
            @Override
            public void onClick(View v) {
                switch (v.getId()){
                    case R.id.btnSetWoman:
                        btnSetWoman.setSelected(true);
                        btnSetMan.setSelected(false);
                        btnSetWoman.setHintTextColor(Color.WHITE);
                        btnSetMan.setHintTextColor(Color.GRAY);
                        break;
                    case R.id.btnSetMan:
                        btnSetMan.setSelected(true);
                        btnSetWoman.setSelected(false);
                        btnSetMan.setHintTextColor(Color.WHITE);
                        btnSetWoman.setHintTextColor(Color.GRAY);
                        break;
                }
            }
        };
        btnSetWoman.setOnClickListener(onClickListener);
        btnSetMan.setOnClickListener(onClickListener);

        tvDisconnection.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMessge();
            }
        });
    }

    //안드로이드 폰으로 구현시 사용!!!!!!
    //사용자 이미지 핸드폰 사집첩에서 선택, 메인페이지 이미지도 똑같이 바뀌게 해야함
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == GET_GALLERY_IMAGE && resultCode == RESULT_OK && data != null && data.getData() != null) {

            Uri selectedImageUri = data.getData();
            ivSetUserImage.setImageURI(selectedImageUri);
        }
    }

    //'연동 해제'를 눌렀을 때 경고창메세지, 해당 사용자 DB 데이터 삭제, 탈퇴처리, 자동으로 로그아웃 처리
    //여태까지 저장된 데이터 리셋(아이디, 비밀번호, 회원정보)
    public void showMessge(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("경고");
        builder.setMessage("연동 해제하시겠습니까?").setCancelable(false).
                setPositiveButton("예", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //Toast.makeText(getApplicationContext(), "예를 눌렀습니다", Toast.LENGTH_SHORT).show();

                        BluetoothSPP bt2 = ((Device1Activity)Device1Activity.context).bt;
                        bt2.stopService(); //블루투스 중지

                    }
                }).setNegativeButton("아니오", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(getApplicationContext(), "아니오를 눌렀습니다", Toast.LENGTH_SHORT).show();
            }
        });
        builder.show();
    }

    //툴바 뒤로가기 버튼 동작 메서드
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId()) {
            case android.R.id.home: {
                finish();
                return true;
            }
        }
        return super.onOptionsItemSelected(item);
    }

}