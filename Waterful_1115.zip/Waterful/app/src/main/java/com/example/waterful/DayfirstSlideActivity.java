package com.example.waterful;
// day 첫번째 차트
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;

import java.util.ArrayList;

public class DayfirstSlideActivity extends Fragment {
    BarChart bar;
    ArrayList<BarEntry> barEntry;
    ArrayList<String> barEntryLabel;
    BarDataSet barDataSet;
    BarData barData;

    public DayfirstSlideActivity( ) {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        ViewGroup rootview = (ViewGroup)inflater.inflate(R.layout.dayfirst_slide, container,false);

        //bar차트 기본 설정
        bar = rootview.findViewById(R.id.barChart1);
        barEntry = new ArrayList<>();   //x축 하나 당 들어가는 값
        barEntryLabel = new ArrayList<>();

        AddValues();
        barEntryLabels();

        barDataSet = new BarDataSet(barEntry, "섭취량");  //BarDataSet : 그래프 그룹의 이름, 하단에 위치. entry를 넣고 그래프 선의 색을 설정할 수 있음
        barData = new BarData(barEntryLabel, barDataSet); //barEntryLabel : x축 레이블값
        barDataSet.setColor(ContextCompat.getColor(getContext(),R.color.colorPrimary)); //그래프 그룹 색 선택

        //x축 설정
        XAxis xAxis = bar.getXAxis(); // x축 속성 설정 (위치, 색상 등). x축에 대한 정보를 view에서 가져온다
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM); //x 축 표시에 대한 위치 설정
        xAxis.setTextColor(ContextCompat.getColor(getContext(),R.color.colorPrimaryDark)); // X축 텍스트컬러설정
        xAxis.setGridColor(ContextCompat.getColor(getContext(), R.color.colorWhite)); // X축 줄의 컬러 설정

        YAxis yAxisLeft = bar.getAxisLeft(); //Y축의 왼쪽면 설정
        yAxisLeft.setTextColor(ContextCompat.getColor(getContext(), R.color.colorPrimaryDark)); //Y축 텍스트 컬러 설정
        yAxisLeft.setGridColor(ContextCompat.getColor(getContext(), R.color.colorWhite)); // X축 줄의 컬러 설정

        YAxis yAxisRight = bar.getAxisRight(); //Y축의 오른쪽면 설정
        yAxisRight.setDrawLabels(false);
        yAxisRight.setDrawAxisLine(false);
        yAxisRight.setDrawGridLines(false);

        bar.setData(barData);
        bar.animateY(3000); //그래프 그릴 시 y축으로 애니메이션
        //Chart end

        return rootview;
    }
    //임의로 막대 그래프 값을 넣음
    public void AddValues(){
        barEntry.add(new BarEntry(1900f, 0));    //실수형 값
        barEntry.add(new BarEntry(800f, 1));
        barEntry.add(new BarEntry(250f, 2));
        barEntry.add(new BarEntry(90f, 3));
        barEntry.add(new BarEntry(650f, 4));
        barEntry.add(new BarEntry(765f, 5));
        barEntry.add(new BarEntry(1189f, 6));
        barEntry.add(new BarEntry(800f, 7));
        barEntry.add(new BarEntry(250f, 8));
        barEntry.add(new BarEntry(90f, 9));
        barEntry.add(new BarEntry(650f, 10));
        barEntry.add(new BarEntry(765f, 11));
        barEntry.add(new BarEntry(1189f, 12));
        barEntry.add(new BarEntry(765f, 13));
        barEntry.add(new BarEntry(1189f, 14));
    }

    //x축
    public void barEntryLabels(){
        barEntryLabel.add("1");
        barEntryLabel.add("2");
        barEntryLabel.add("3");
        barEntryLabel.add("4");
        barEntryLabel.add("5");
        barEntryLabel.add("6");
        barEntryLabel.add("7");
        barEntryLabel.add("8");
        barEntryLabel.add("9");
        barEntryLabel.add("10");
        barEntryLabel.add("11");
        barEntryLabel.add("12");
        barEntryLabel.add("13");
        barEntryLabel.add("14");
        barEntryLabel.add("15");
    }
}