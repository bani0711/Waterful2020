package com.example.waterful;

/* 업적 페이지 - 리사이클러뷰를 구현하기 위한 순위 어댑터 */

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RankingAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    //RecyclerView의 행을 표시하는 클래스 정의
    public static class RankingViewHolder extends RecyclerView.ViewHolder {
        ImageView ivRankingPicture;
        TextView tvRankingNickname;
        TextView tvRanking;
        TextView tvAchivePoint;
        CardView cardView;

        RankingViewHolder(View view) {
            super(view);
            ivRankingPicture = view.findViewById(R.id.ivRankingPicture);
            tvRankingNickname = view.findViewById(R.id.tvRankingNickname);
            tvRanking = view.findViewById(R.id.tvRanking);
            tvAchivePoint = view.findViewById(R.id.tvAchivePoint);
            cardView = view.findViewById(R.id.cardView);
        }
    } //RankingViewHolder end

    private ArrayList<RankingInfo> rankingInfoArrayList;
    RankingAdapter(ArrayList<RankingInfo> rankingInfoArrayList) {
        this.rankingInfoArrayList = rankingInfoArrayList;
    }

    //RecyclerView의 행을 표시하는데 사용되는 레이아웃 xml 가져옴
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_view_ranking, parent, false);

        return new RankingAdapter.RankingViewHolder(v);
    }

    //RecyclerView의 행에 보여질 iv와 tv 설정
    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        RankingAdapter.RankingViewHolder rankingViewHolder = (RankingAdapter.RankingViewHolder)holder;

        rankingViewHolder.ivRankingPicture.setImageResource(rankingInfoArrayList.get(position).drawbleID);
        rankingViewHolder.tvRankingNickname.setText(rankingInfoArrayList.get(position).nickname);
        rankingViewHolder.tvRanking.setText(rankingInfoArrayList.get(position).ranking);
        rankingViewHolder.tvAchivePoint.setText(rankingInfoArrayList.get(position).achivePoint);

        //index(position) 값에 따라 색상 설정하기
        if(position == 0) {
            ((RankingViewHolder) holder).cardView.setCardBackgroundColor(Color.parseColor("#FFED00")); //gold
        } else if(position == 1) {
            ((RankingViewHolder) holder).cardView.setCardBackgroundColor(Color.parseColor("#CECECE")); //silver
        } else if(position == 2) {
            ((RankingViewHolder) holder).cardView.setCardBackgroundColor(Color.parseColor("#FFBA53")); //bronze
        }
    }

    //RecyclerView의 행 갯수 리턴
    @Override
    public int getItemCount() {
        return rankingInfoArrayList.size();
    }
}
