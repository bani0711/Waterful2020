package com.example.waterful;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Device2Activity extends AppCompatActivity {
Button btnReconnect;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_device2);

        btnReconnect = findViewById(R.id.btnReconnect);

        //코스터 재연동하기 위해 intro1로 이동
        btnReconnect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Device1Activity.class);
                startActivity(intent);
            }
        });
    }
}